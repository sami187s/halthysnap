import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  StatusBar,
  Platform,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import AlternativeBarcodeScanner from '../components/AlternativeBarcodeScanner';
import { getDebugInfo } from '../utils/platformUtils';
import { logDeviceInfo } from '../utils/deviceDetection';

const HomeScreen = ({ navigation }) => {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Add emergency timeout to ensure component always loads
    const loadTimer = setTimeout(() => {
      setIsLoaded(true);
    }, 50);

    getBarCodeScannerPermissions();
    
    // Add comprehensive device detection logging
    const deviceInfo = logDeviceInfo();
    console.log('HomeScreen mounted on device:', {
      width: screenWidth,
      height: screenHeight,
      isTablet,
      platform: Platform.OS,
      version: Platform.Version,
      deviceInfo
    });

    return () => clearTimeout(loadTimer);
  }, []);

  // Reset scanning state when screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      console.log('HomeScreen focused - resetting states');
      setScanning(false);
      setScanned(false);
      
      // Force component refresh to clear any residual camera state
      setTimeout(() => {
        setScanning(false);
      }, 100);
    }, [])
  );

  const getBarCodeScannerPermissions = async () => {
    // Permission will be handled by the camera component
    setHasPermission(true);
  };

  const handleBarCodeScanned = ({ type, data }) => {
    console.log('Barcode scanned in HomeScreen:', { type, data });
    
    // Immediately stop scanning to prevent issues
    setScanned(true);
    setScanning(false);
    
    // Navigate with fresh data
    navigation.navigate('Results', { 
      barcode: data,
      scanTime: Date.now() // Ensure fresh data
    });
  };

  const startScanning = () => {
    console.log('Starting scanner...');
    const debugInfo = getDebugInfo();
    console.log('Platform debug info:', debugInfo);
    
    if (hasPermission === null) {
      Alert.alert('Permission Required', 'Camera permission is required to scan barcodes.');
      return;
    }
    if (hasPermission === false) {
      Alert.alert('No Access', 'No access to camera. Please enable camera permissions in settings.');
      return;
    }
    
    // Reset states before scanning
    setScanned(false);
    setScanning(true);
  };

  const navigateToSearch = () => {
    navigation.navigate('Search');
  };

  if (scanning) {
    return (
      <View style={{ flex: 1 }}>
        <AlternativeBarcodeScanner
          onBarCodeScanned={handleBarCodeScanned}
          onClose={() => {
            console.log('Scanner closed');
            setScanning(false);
            setScanned(false);
          }}
        />
      </View>
    );
  }

  // Emergency fallback for iPad issues
  if (!isLoaded) {
    return (
      <View style={{ flex: 1, backgroundColor: '#F8F9FA', justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ fontSize: 24, color: '#4CAF50', fontWeight: 'bold' }}>
          Vee: Product Check
        </Text>
        <Text style={{ fontSize: 16, color: '#666', marginTop: 20 }}>
          Loading app...
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F9FA" />
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>HealthyScan</Text>
          <Text style={styles.headerSubtitle}>
            Scan products to check their safety
          </Text>
        </View>
        <TouchableOpacity
          style={styles.aboutButton}
          onPress={() => navigation.navigate('About')}
          activeOpacity={0.7}
        >
          <Ionicons name="information-circle-outline" size={28} color="#4CAF50" />
        </TouchableOpacity>
      </View>

      {/* Logo/Icon */}
      <View style={styles.logoContainer}>
        <View style={styles.logoCircle}>
          <Ionicons name="leaf" size={60} color="#4CAF50" />
        </View>
      </View>

      {/* Main Content */}
      <View style={styles.content}>
        <Text style={styles.welcomeText}>
          Discover what's in your personal care products
        </Text>
        
        <Text style={styles.descriptionText}>
          Scan the barcode to get an instant health score and ingredient analysis
        </Text>

        {/* Scan Button */}
        <TouchableOpacity
          style={styles.scanButton}
          onPress={startScanning}
          activeOpacity={0.8}
          hitSlop={{ top: 5, bottom: 5, left: 5, right: 5 }}
          accessible={true}
          accessibilityLabel="Start barcode scanning"
        >
          <Ionicons name="barcode-outline" size={40} color="#fff" />
          <Text style={styles.scanButtonText}>Scan Barcode</Text>
        </TouchableOpacity>

        {/* Search Alternative */}
        <TouchableOpacity
          style={styles.searchButton}
          onPress={navigateToSearch}
          activeOpacity={0.8}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          accessible={true}
          accessibilityLabel="Search products by name"
        >
          <Ionicons name="search-outline" size={24} color="#4CAF50" />
          <Text style={styles.searchButtonText}>Search by name</Text>
        </TouchableOpacity>

        {/* Test Button for Development */}
        <TouchableOpacity
          style={styles.testButton}
          onPress={() => navigation.navigate('Results', { barcode: '3600531037024' })}
          activeOpacity={0.8}
        >
          <Ionicons name="flask-outline" size={20} color="#666" />
          <Text style={styles.testButtonText}>Test with sample product</Text>
        </TouchableOpacity>

        <View style={styles.testInfo}>
          <Text style={styles.testInfoText}>
            Try scanning any barcode - if not found in database, we'll show a demo analysis
          </Text>
          <Text style={styles.testInfoText}>
            Common test barcodes: 3600531037024, 7622210995957, 3274080005003
          </Text>
        </View>
      </View>
    </View>
  );
};

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');
const isTablet = screenWidth > 768;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    maxWidth: isTablet ? 600 : '100%',
    alignSelf: 'center',
    width: '100%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 10,
  },
  headerContent: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2E7D32',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  aboutButton: {
    padding: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    minWidth: 44,
    minHeight: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  logoCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#E8F5E8',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: isTablet ? 48 : 24,
    justifyContent: 'center',
    alignItems: 'center',
    maxWidth: isTablet ? 500 : '100%',
    alignSelf: 'center',
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
    marginBottom: 12,
  },
  descriptionText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 22,
  },
  scanButton: {
    backgroundColor: '#4CAF50',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
    paddingVertical: 16,
    borderRadius: 30,
    marginBottom: 16,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  scanButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    marginLeft: 12,
  },
  searchButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#4CAF50',
    backgroundColor: 'transparent',
  },
  searchButtonText: {
    color: '#4CAF50',
    fontSize: 16,
    fontWeight: '500',
    marginLeft: 8,
  },
  testButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    marginTop: 12,
  },
  testButtonText: {
    color: '#666',
    fontSize: 14,
    marginLeft: 6,
  },
  testInfo: {
    marginTop: 16,
    paddingHorizontal: 20,
  },
  testInfoText: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    lineHeight: 16,
  },
});

export default HomeScreen;
