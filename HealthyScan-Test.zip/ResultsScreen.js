import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  StatusBar,
  Platform,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { fetchProductByBarcode } from '../services/openBeautyFactsAPI';
import { analyzeIngredients, getScoreColor, getScoreGrade, getRecommendation } from '../utils/ingredientAnalyzer';

// Helper function to get score label
const getScoreLabel = (score) => {
  if (score >= 75) return 'Excellent';
  if (score >= 50) return 'Good';
  if (score >= 25) return 'Mediocre';
  return 'Poor';
};

const ResultsScreen = ({ route, navigation }) => {
  // Safe route parameter extraction with fallback
  const barcode = route?.params?.barcode || null;
  
  const [loading, setLoading] = useState(true);
  const [product, setProduct] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    console.log('ResultsScreen mounted with barcode:', barcode);
    if (barcode) {
      fetchProductData();
    } else {
      console.error('No barcode provided to ResultsScreen');
      setError('No barcode provided');
      setLoading(false);
    }
  }, [barcode]);

  const fetchProductData = async () => {
    if (!barcode) {
      setError('Invalid barcode');
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    setProduct(null);
    setAnalysis(null);
    
    try {
      console.log('Fetching product for barcode:', barcode);
      const productData = await fetchProductByBarcode(barcode);
      
      if (productData && productData.product_name) {
        console.log('Product found:', productData.product_name);
        setProduct(productData);
        
        // Safe ingredients analysis
        if (productData.ingredients_text && typeof productData.ingredients_text === 'string') {
          try {
            const ingredientAnalysis = analyzeIngredients(productData.ingredients_text);
            if (ingredientAnalysis) {
              setAnalysis(ingredientAnalysis);
            }
          } catch (analysisError) {
            console.error('Error analyzing ingredients:', analysisError);
            // Don't set error here, just continue without analysis
          }
        }
      } else {
        setError('Product not found in our database');
      }
    } catch (err) {
      console.error('Error fetching product:', err);
      setError(`Failed to fetch product information: ${err.message || 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleGoBack = () => {
    try {
      console.log('Going back to home');
      if (navigation && navigation.goBack) {
        navigation.goBack();
      } else if (navigation && navigation.navigate) {
        navigation.navigate('Home');
      }
    } catch (navError) {
      console.error('Navigation error:', navError);
    }
  };

  const handleScanAnother = () => {
    try {
      console.log('Navigating to scan another product');
      if (navigation && navigation.navigate) {
        navigation.navigate('Home');
      }
    } catch (navError) {
      console.error('Navigation error:', navError);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="dark-content" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Analyzing product...</Text>
        </View>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="dark-content" />
        
        <View style={styles.header}>
          <TouchableOpacity onPress={handleGoBack} style={styles.headerButton}>
            <Ionicons name="arrow-back" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Product Analysis</Text>
          <TouchableOpacity onPress={handleScanAnother} style={styles.headerButton}>
            <Ionicons name="barcode-outline" size={24} color="#333" />
          </TouchableOpacity>
        </View>

        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle-outline" size={64} color="#F44336" />
          <Text style={styles.errorTitle}>Product Not Found</Text>
          <Text style={styles.errorMessage}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={handleScanAnother}>
            <Text style={styles.retryButtonText}>Scan Another Product</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      {/* Fixed Header - ALWAYS TOUCHABLE */}
      <View style={styles.header}>
        <TouchableOpacity 
          onPress={handleGoBack} 
          style={styles.headerButton}
          testID="backButton"
        >
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Product Analysis</Text>
        <TouchableOpacity 
          onPress={() => navigation.navigate('About')} 
          style={styles.headerButton}
          testID="aboutButton"
        >
          <Ionicons name="information-circle-outline" size={24} color="#333" />
        </TouchableOpacity>
      </View>

      {/* SIMPLE ScrollView - NO complex props */}
      <ScrollView style={styles.scrollView}>
        <View style={styles.content}>
          
          {/* Product Info Card */}
          <TouchableOpacity style={styles.card} activeOpacity={0.9}>
            <View style={styles.productHeader}>
              {product?.image_url && (
                <Image 
                  source={{ uri: product.image_url }} 
                  style={styles.productImage}
                  onError={() => console.log('Image failed to load')}
                  defaultSource={require('../../assets/icon.png')}
                />
              )}
              <View style={styles.productInfo}>
                <Text style={styles.productName}>{product?.product_name || 'Unknown Product'}</Text>
                <Text style={styles.brandName}>{product?.brands || 'Unknown Brand'}</Text>
                <Text style={styles.barcode}>Barcode: {barcode || 'N/A'}</Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* Health Score Card */}
          {analysis && (
            <TouchableOpacity style={styles.card} activeOpacity={0.9}>
              <Text style={styles.cardTitle}>Health Score & Grade</Text>
              <View style={styles.scoreContainer}>
                <View style={[styles.scoreCircle, { borderColor: getScoreColor(analysis.score || 0) }]}>
                  <Text style={[styles.scoreNumber, { color: getScoreColor(analysis.score || 0) }]}>
                    {analysis.score || 0}
                  </Text>
                  <Text style={styles.scoreOutOf}>/100</Text>
                </View>
                <View style={styles.scoreInfo}>
                  <Text style={[styles.scoreGrade, { color: getScoreColor(analysis.score || 0) }]}>
                    Grade {getScoreGrade(analysis.score || 0)} - {getScoreLabel(analysis.score || 0)}
                  </Text>
                  <Text style={styles.recommendation}>
                    {getRecommendation(analysis.score || 0)}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          )}

          {/* Score Legend */}
          <TouchableOpacity style={styles.card} activeOpacity={0.9}>
            <Text style={styles.cardTitle}>Score Guide</Text>
            <View style={styles.legendContainer}>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#4CAF50' }]} />
                <Text style={styles.legendText}>75-100: Excellent</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#8BC34A' }]} />
                <Text style={styles.legendText}>50-74: Good</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#FF9800' }]} />
                <Text style={styles.legendText}>25-49: Mediocre</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#F44336' }]} />
                <Text style={styles.legendText}>0-24: Poor</Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* Risk Assessment */}
          {analysis && (
            <TouchableOpacity style={styles.card} activeOpacity={0.9}>
              <View style={styles.cardHeader}>
                <Ionicons name="warning-outline" size={20} color="#FF9800" />
                <Text style={styles.cardHeaderTitle}>Risk Assessment</Text>
              </View>

              {analysis.badIngredients?.length > 0 && (
                <View style={styles.riskSection}>
                  <View style={styles.riskHeader}>
                    <Ionicons name="close-circle" size={16} color="#F44336" />
                    <Text style={styles.riskTitle}>High Risk Ingredients</Text>
                  </View>
                  {analysis.badIngredients.map((ingredient, index) => (
                    <View key={index} style={styles.riskItem}>
                      <Text style={styles.ingredientName}>{ingredient.name}</Text>
                      <Text style={styles.ingredientDescription}>{ingredient.description}</Text>
                      <Text style={[styles.ingredientScore, { color: getScoreColor(ingredient.score) }]}>
                        Score: {ingredient.score}/100
                      </Text>
                    </View>
                  ))}
                </View>
              )}

              {analysis.moderateIngredients?.length > 0 && (
                <View style={styles.riskSection}>
                  <View style={styles.riskHeader}>
                    <Ionicons name="alert-circle" size={16} color="#FF9800" />
                    <Text style={styles.moderateTitle}>Moderate Risk Ingredients</Text>
                  </View>
                  {analysis.moderateIngredients.map((ingredient, index) => (
                    <View key={index} style={[styles.riskItem, { backgroundColor: '#FFF3E0' }]}>
                      <Text style={styles.ingredientName}>{ingredient.name}</Text>
                      <Text style={styles.ingredientDescription}>{ingredient.description}</Text>
                      <Text style={[styles.ingredientScore, { color: getScoreColor(ingredient.score) }]}>
                        Score: {ingredient.score}/100
                      </Text>
                    </View>
                  ))}
                </View>
              )}

              {analysis.goodIngredients?.length > 0 && (
                <View style={styles.riskSection}>
                  <View style={styles.riskHeader}>
                    <Ionicons name="checkmark-circle" size={16} color="#4CAF50" />
                    <Text style={styles.safeTitle}>Safe Ingredients</Text>
                  </View>
                  {analysis.goodIngredients.map((ingredient, index) => (
                    <View key={index} style={[styles.riskItem, { backgroundColor: '#E8F5E8' }]}>
                      <Text style={styles.ingredientName}>{ingredient.name}</Text>
                      <Text style={styles.ingredientDescription}>{ingredient.description || 'Generally considered safe.'}</Text>
                      <Text style={[styles.ingredientScore, { color: getScoreColor(ingredient.score) }]}>
                        Score: {ingredient.score}/100
                      </Text>
                    </View>
                  ))}
                </View>
              )}
            </TouchableOpacity>
          )}

          {/* Action Buttons */}
          <TouchableOpacity style={styles.scanButton} onPress={handleScanAnother}>
            <Ionicons name="barcode-outline" size={24} color="#fff" />
            <Text style={styles.scanButtonText}>Scan Another Product</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.sourcesButton} 
            onPress={() => navigation.navigate('Sources')}
          >
            <Ionicons name="library-outline" size={20} color="#4CAF50" />
            <Text style={styles.sourcesButtonText}>View Data Sources</Text>
          </TouchableOpacity>

          <View style={styles.bottomPadding} />
        </View>
      </ScrollView>
    </View>
  );
};

const { width: screenWidth } = Dimensions.get('window');
const isTablet = screenWidth > 768;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    maxWidth: isTablet ? 700 : '100%',
    alignSelf: 'center',
    width: '100%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#F8F9FA',
    borderBottomWidth: 1,
    borderBottomColor: '#E1E8ED',
    zIndex: 1000, // Ensure header is always on top
  },
  headerButton: {
    padding: 10,
    borderRadius: 20,
    backgroundColor: '#4CAF50',
    minWidth: 44,
    minHeight: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  errorTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 16,
    marginBottom: 8,
  },
  errorMessage: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 32,
  },
  retryButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
    minHeight: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  retryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardHeaderTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginLeft: 8,
  },
  productHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  productImage: {
    width: 80,
    height: 80,
    borderRadius: 12,
    marginRight: 16,
    backgroundColor: '#F5F5F5',
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
    lineHeight: 22,
  },
  brandName: {
    fontSize: 16,
    color: '#666',
    marginBottom: 4,
    textTransform: 'capitalize',
  },
  barcode: {
    fontSize: 14,
    color: '#999',
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scoreCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 4,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 20,
    backgroundColor: '#F9F9F9',
  },
  scoreNumber: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  scoreOutOf: {
    fontSize: 12,
    color: '#666',
    marginTop: -2,
  },
  scoreInfo: {
    flex: 1,
  },
  scoreGrade: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  recommendation: {
    fontSize: 14,
    color: '#666',
    lineHeight: 18,
  },
  legendContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '48%',
    marginBottom: 8,
  },
  legendColor: {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginRight: 8,
  },
  legendText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  riskSection: {
    marginBottom: 16,
  },
  riskHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  riskTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F44336',
    marginLeft: 6,
  },
  moderateTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FF9800',
    marginLeft: 6,
  },
  safeTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4CAF50',
    marginLeft: 6,
  },
  riskItem: {
    padding: 12,
    backgroundColor: '#FFEBEE',
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#F44336',
  },
  ingredientName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
    textTransform: 'capitalize',
  },
  ingredientDescription: {
    fontSize: 13,
    color: '#666',
    lineHeight: 18,
    marginBottom: 4,
  },
  ingredientScore: {
    fontSize: 12,
    fontWeight: '600',
  },
  scanButton: {
    backgroundColor: '#4CAF50',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 25,
    marginTop: 20,
    marginBottom: 10,
  },
  scanButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  sourcesButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 20,
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#4CAF50',
    backgroundColor: 'transparent',
  },
  sourcesButtonText: {
    color: '#4CAF50',
    fontSize: 14,
    fontWeight: '500',
    marginLeft: 6,
  },
  bottomPadding: {
    height: 30,
  },
});

export default ResultsScreen;
